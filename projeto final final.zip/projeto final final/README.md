# API Criptomoedas

## Sobre
projeto final na escola Infinity school

## Como utiliza-lo

Primeiro faça o clone do projeto, após isso instale ele com o comando npm install na sua pasta que você criou e abriu no VS Code. E por fim vamos ligar o serve fake da api. Entre dentro da pasta "api" com o comando dentro do terminal "cd api" após isso execute o seguinte "npx json-server --watch db.json" então abrimos um server local que mostrará qual url ele será no terminal. Exemplo "https://localhost:3000"

Agora é só usar seu conhecimento de consumir API.
